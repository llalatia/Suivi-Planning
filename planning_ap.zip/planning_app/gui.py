# -*- coding: utf-8 -*-
"""
gui.py — Interface graphique (Tkinter) de l'outil de Macro-Planning Broderie.

100% hors-ligne : aucune connexion réseau n'est utilisée.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import datetime
import colorsys

import db
import logic
import excel_import
import excel_export

APP_TITLE = "Macro-Planning Broderie — Gestion hors-ligne"

COLOR_OK = "#FFFFFF"
COLOR_RETARD = "#FFC7CE"
COLOR_TERMINE = "#C6EFCE"
COLOR_TBC = "#FFF2CC"
COLOR_COURANTE = "#FFFACD"
COLOR_LANCEMENT = "#FFD9A0"
COLOR_LIMITE = "#FF9999"

# Palette du tableau de bord
DASH_BG = "#F4F6F8"
DASH_CARD_BG = "#FFFFFF"
DASH_GREEN = "#2E7D32"
DASH_GREEN_BG = "#E6F4EA"
DASH_ORANGE = "#B26A00"
DASH_ORANGE_BG = "#FFF1DC"
DASH_RED = "#C62828"
DASH_RED_BG = "#FDE7E7"
DASH_BLUE = "#1565C0"
DASH_BLUE_BG = "#E8F0FE"
DASH_GREY = "#616161"
DASH_GREY_BG = "#ECECEC"

STATUT_LABELS = {
    "ok": ("En cours — planifiée", DASH_BLUE, DASH_BLUE_BG),
    "sous_planifie": ("Sous-planifiée (retard)", DASH_RED, DASH_RED_BG),
    "termine": ("Terminée", DASH_GREEN, DASH_GREEN_BG),
    "tbc": ("Heure/pcs à confirmer", DASH_ORANGE, DASH_ORANGE_BG),
}

# Palette pour le graphique en anneaux (une couleur par client, déclinée par commande)
PALETTE_CLIENTS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B2",
                    "#937860", "#DA8BC3", "#8C8C8C", "#CCB974", "#64B5CD",
                    "#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD"]


def _hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in rgb)


def _shade_color(hex_color, delta_l):
    """Éclaircit (delta_l > 0) ou assombrit (delta_l < 0) une couleur, en
    gardant la même teinte — utilisé pour décliner la couleur d'un client
    sur ses différentes commandes."""
    r, g, b = _hex_to_rgb(hex_color)
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    l = min(0.90, max(0.20, l + delta_l))
    r2, g2, b2 = colorsys.hls_to_rgb(h, l, s)
    return _rgb_to_hex((r2 * 255, g2 * 255, b2 * 255))


def _client_color(index):
    base = PALETTE_CLIENTS[index % len(PALETTE_CLIENTS)]
    cycle = index // len(PALETTE_CLIENTS)
    return _shade_color(base, cycle * -0.08) if cycle else base


def fmt(v, decimals=2):
    if v is None:
        return ""
    if isinstance(v, float):
        if v == int(v):
            return str(int(v))
        return f"{v:.{decimals}f}"
    return str(v)


# =========================================================================
# Boîte de dialogue : Ajouter / Modifier une commande
# =========================================================================
class CommandeDialog(tk.Toplevel):
    def __init__(self, parent, commande=None):
        super().__init__(parent)
        self.title("Commande" if commande is None else "Modifier la commande")
        self.resizable(False, False)
        self.result = None
        self.commande = commande

        fields = [
            ("client", "Client *"),
            ("modele", "Modèle *"),
            ("qte_commande", "Qté en commande *"),
            ("unite", "Unité"),
            ("heure_pcs", "Heure / pcs (laisser vide si TBC)"),
            ("qte_finie", "Qté finie"),
            ("date_limite_client", "Date limite client (AAAA-MM-JJ)"),
            ("date_lancement", "Date de lancement (AAAA-MM-JJ)"),
            ("notes", "Notes"),
        ]
        self.vars = {}
        frm = ttk.Frame(self, padding=15)
        frm.grid(row=0, column=0)

        for i, (key, label) in enumerate(fields):
            ttk.Label(frm, text=label).grid(row=i, column=0, sticky="w", pady=3)
            var = tk.StringVar()
            ent = ttk.Entry(frm, textvariable=var, width=40)
            ent.grid(row=i, column=1, pady=3, padx=(8, 0))
            self.vars[key] = var

        self.tbc_var = tk.BooleanVar()
        ttk.Checkbutton(frm, text="Heure/pcs = TBC (à confirmer)",
                         variable=self.tbc_var).grid(row=len(fields), column=1, sticky="w")

        if commande:
            c = dict(commande)
            self.vars["client"].set(c.get("client") or "")
            self.vars["modele"].set(c.get("modele") or "")
            self.vars["qte_commande"].set(fmt(c.get("qte_commande")))
            self.vars["unite"].set(c.get("unite") or "PCS")
            self.vars["heure_pcs"].set(fmt(c.get("heure_pcs")) if not c.get("heure_pcs_tbc") else "")
            self.vars["qte_finie"].set(fmt(c.get("qte_finie")))
            self.vars["date_limite_client"].set(c.get("date_limite_client") or "")
            self.vars["date_lancement"].set(c.get("date_lancement") or "")
            self.vars["notes"].set(c.get("notes") or "")
            self.tbc_var.set(bool(c.get("heure_pcs_tbc")))
        else:
            self.vars["unite"].set("PCS")
            self.vars["qte_finie"].set("0")

        btns = ttk.Frame(frm)
        btns.grid(row=len(fields) + 1, column=0, columnspan=2, pady=(15, 0))
        ttk.Button(btns, text="Annuler", command=self.destroy).pack(side="right", padx=5)
        ttk.Button(btns, text="Enregistrer", command=self._on_save).pack(side="right")

        self.transient(parent)
        self.grab_set()
        self.wait_window(self)

    def _on_save(self):
        try:
            client = self.vars["client"].get().strip()
            modele = self.vars["modele"].get().strip()
            if not client or not modele:
                messagebox.showerror("Champs requis", "Client et Modèle sont obligatoires.", parent=self)
                return
            qte_commande = float(self.vars["qte_commande"].get().replace(",", ".") or 0)
            qte_finie = float(self.vars["qte_finie"].get().replace(",", ".") or 0)
            heure_raw = self.vars["heure_pcs"].get().strip()
            tbc = self.tbc_var.get() or (heure_raw == "")
            heure_pcs = None
            if not tbc and heure_raw:
                heure_pcs = float(heure_raw.replace(",", "."))

            def clean_date(s):
                s = s.strip()
                if not s:
                    return None
                datetime.datetime.strptime(s, "%Y-%m-%d")  # validation
                return s

            data = {
                "client": client,
                "modele": modele,
                "qte_commande": qte_commande,
                "unite": self.vars["unite"].get().strip() or "PCS",
                "heure_pcs": heure_pcs,
                "heure_pcs_tbc": 1 if tbc else 0,
                "qte_finie": qte_finie,
                "date_limite_client": clean_date(self.vars["date_limite_client"].get()),
                "date_lancement": clean_date(self.vars["date_lancement"].get()),
                "notes": self.vars["notes"].get().strip() or None,
            }
        except ValueError as e:
            messagebox.showerror("Valeur invalide",
                                  f"Vérifiez les champs numériques / dates.\n({e})", parent=self)
            return

        self.result = data
        self.destroy()


# =========================================================================
# Onglet : Commandes
# =========================================================================
class OngletCommandes(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._build()
        self.refresh()

    def _build(self):
        toolbar = ttk.Frame(self)
        toolbar.pack(fill="x", padx=8, pady=8)
        ttk.Button(toolbar, text="+ Ajouter", command=self.on_add).pack(side="left")
        ttk.Button(toolbar, text="Modifier", command=self.on_edit).pack(side="left", padx=5)
        ttk.Button(toolbar, text="Dupliquer", command=self.on_duplicate).pack(side="left")
        ttk.Button(toolbar, text="Supprimer", command=self.on_delete).pack(side="left", padx=5)
        ttk.Button(toolbar, text="Planifier ➜", command=self.on_plan).pack(side="left", padx=15)

        ttk.Label(toolbar, text="Filtrer client :").pack(side="left", padx=(30, 4))
        self.filter_var = tk.StringVar()
        ent = ttk.Entry(toolbar, textvariable=self.filter_var, width=20)
        ent.pack(side="left")
        ent.bind("<KeyRelease>", lambda e: self.refresh())

        legende = ttk.Frame(self)
        legende.pack(fill="x", padx=8, pady=(0, 4))
        ttk.Label(legende, text="Statuts : ", font=("Calibri", 9, "bold")).pack(side="left")
        for key in ("ok", "sous_planifie", "termine", "tbc"):
            label, fg, bg = STATUT_LABELS[key]
            tk.Label(legende, text=f" {label} ", bg=bg, fg=fg,
                     font=("Calibri", 9)).pack(side="left", padx=4)

        cols = ("client", "modele", "qte_commande", "unite", "heure_pcs",
                "qte_finie", "reste", "programme", "ecart", "statut")
        headers = ["Client", "Modèle", "Qté commande", "Unité", "Heure/pcs",
                   "Qté finie", "Reste à faire", "Total programmé", "Écart", "Statut"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        for c, h in zip(cols, headers):
            self.tree.heading(c, text=h)
            width = 200 if c in ("client", "modele") else 110
            self.tree.column(c, width=width, anchor="center" if c not in ("client", "modele") else "w")
        self.tree.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tree.bind("<Double-1>", lambda e: self.on_plan())

        vsb = ttk.Scrollbar(self.tree, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.tag_configure("retard", background=DASH_RED_BG)
        self.tree.tag_configure("termine", background=DASH_GREEN_BG)
        self.tree.tag_configure("tbc", background=DASH_ORANGE_BG)

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        filt = self.filter_var.get().strip().lower()
        for c in db.list_commandes():
            c = dict(c)
            if filt and filt not in c["client"].lower() and filt not in c["modele"].lower():
                continue
            reste = logic.qte_reste_a_faire(c["qte_commande"], c["qte_finie"])
            total_prog = db.total_pieces_commande(c["id"])
            ecart = round((total_prog or 0) - (reste or 0), 2)
            statut = logic.statut_commande(c["qte_commande"], c["qte_finie"], total_prog)
            tag = ""
            if statut == "termine":
                tag = "termine"
            elif statut == "sous_planifie":
                tag = "retard"
            elif c["heure_pcs_tbc"]:
                tag = "tbc"

            statut_key = "tbc" if (statut == "ok" and c["heure_pcs_tbc"]) else statut
            statut_label = STATUT_LABELS[statut_key][0]
            heure_display = "TBC" if c["heure_pcs_tbc"] else fmt(c["heure_pcs"])

            self.tree.insert("", "end", iid=str(c["id"]), values=(
                c["client"], c["modele"], fmt(c["qte_commande"]), c["unite"],
                heure_display, fmt(c["qte_finie"]), fmt(reste), fmt(total_prog),
                fmt(ecart), statut_label,
            ), tags=(tag,))

    def _selected_id(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Sélection", "Sélectionnez d'abord une commande.")
            return None
        return int(sel[0])

    def on_add(self):
        dlg = CommandeDialog(self)
        if dlg.result:
            db.add_commande(dlg.result)
            self.refresh()
            self.app.refresh_all()

    def on_edit(self):
        cid = self._selected_id()
        if cid is None:
            return
        commande = db.get_commande(cid)
        dlg = CommandeDialog(self, commande=commande)
        if dlg.result:
            db.update_commande(cid, dlg.result)
            self.refresh()
            self.app.refresh_all()

    def on_duplicate(self):
        cid = self._selected_id()
        if cid is None:
            return
        c = dict(db.get_commande(cid))
        c.pop("id")
        c["modele"] = c["modele"] + " (copie)"
        db.add_commande(c)
        self.refresh()
        self.app.refresh_all()

    def on_delete(self):
        cid = self._selected_id()
        if cid is None:
            return
        if messagebox.askyesno("Confirmer", "Supprimer définitivement cette commande "
                                             "et son planning associé ?"):
            db.delete_commande(cid)
            self.refresh()
            self.app.refresh_all()

    def on_plan(self):
        cid = self._selected_id()
        if cid is None:
            return
        self.app.open_plan_for_commande(cid)


# =========================================================================
# Onglet : Vue Semaine (édition pivot par semaine)
# =========================================================================
class OngletVueSemaine(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self._build()
        self.refresh()

    def _build(self):
        toolbar = ttk.Frame(self)
        toolbar.pack(fill="x", padx=8, pady=8)
        ttk.Label(toolbar, text="Semaine :").pack(side="left")
        self.semaine_var = tk.StringVar()
        self.combo = ttk.Combobox(toolbar, textvariable=self.semaine_var, state="readonly", width=25)
        self.combo.pack(side="left", padx=6)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.load_semaine())
        ttk.Button(toolbar, text="Définir comme semaine en cours",
                   command=self.set_as_current).pack(side="left", padx=15)
        self.lbl_courante = ttk.Label(toolbar, text="", foreground="#996600")
        self.lbl_courante.pack(side="left", padx=10)

        capa_bar = ttk.Frame(self)
        capa_bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Label(capa_bar, text="Brodeuses disponibles cette semaine :",
                  font=("Calibri", 9, "bold")).pack(side="left")
        self.capacite_var = tk.StringVar()
        ttk.Entry(capa_bar, textvariable=self.capacite_var, width=8).pack(side="left", padx=6)
        ttk.Button(capa_bar, text="Enregistrer", command=self.save_capacite).pack(side="left")
        self.lbl_charge = ttk.Label(capa_bar, text="", font=("Calibri", 9))
        self.lbl_charge.pack(side="left", padx=15)
        ttk.Button(capa_bar, text="Appliquer à plusieurs semaines…",
                   command=self.on_bulk_capacite).pack(side="right")

        cols = ("client", "modele", "heure_pcs", "pieces", "heures", "brodeuses", "statut")
        headers = ["Client", "Modèle", "Heure/pcs", "Nb pièces (éditable)",
                   "Nb heures", "Nb brodeuses", "Statut cellule"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        for c, h in zip(cols, headers):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=150 if c in ("client", "modele") else 110,
                              anchor="w" if c in ("client", "modele") else "center")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.tree.bind("<Double-1>", self.on_double_click)

        footer = ttk.Frame(self)
        footer.pack(fill="x", padx=8, pady=(0, 8))
        self.lbl_totaux = ttk.Label(footer, text="", font=("Calibri", 10, "bold"))
        self.lbl_totaux.pack(side="left")

        help_lbl = ttk.Label(self, foreground="#666666",
                              text="Double-cliquez sur 'Nb pièces' pour saisir la production planifiée. "
                                   "Double-cliquez sur 'Statut cellule' pour marquer "
                                   "Lancement / Limite client.")
        help_lbl.pack(anchor="w", padx=8, pady=(0, 6))

        self.tree.tag_configure("lancement", background=COLOR_LANCEMENT)
        self.tree.tag_configure("limite_client", background=COLOR_LIMITE)
        self.tree.tag_configure("tbc", background=COLOR_TBC)

    def refresh(self):
        semaines = db.list_semaines()
        codes = [s["code"] for s in semaines]
        self.combo["values"] = codes
        if codes and self.semaine_var.get() not in codes:
            courante = db.get_config("semaine_courante")
            self.semaine_var.set(courante if courante in codes else codes[0])
        self.load_semaine()

    def load_semaine(self):
        self.tree.delete(*self.tree.get_children())
        code = self.semaine_var.get()
        if not code:
            return
        sem = db.get_semaine_by_code(code)
        if not sem:
            return
        courante = db.get_config("semaine_courante")
        self.lbl_courante.config(
            text="★ Semaine en cours" if code == courante else "")

        self.capacite_var.set(fmt(sem["capacite_brodeuses"]) if sem["capacite_brodeuses"] else "")

        planning = db.planning_for_semaine(sem["id"])
        total_pieces = 0
        total_heures = 0
        for c in db.list_commandes():
            c = dict(c)
            p = planning.get(c["id"])
            pieces = p["nb_pieces"] if p else None
            statut = p["statut"] if p else "normal"
            heures = None
            if not c["heure_pcs_tbc"]:
                heures = logic.nb_heures(pieces or 0, c["heure_pcs"])
            brodeuses = logic.nb_brodeuses(heures) if heures is not None else None

            if pieces:
                total_pieces += pieces
                if heures:
                    total_heures += heures

            tag = ""
            if statut == "lancement":
                tag = "lancement"
            elif statut == "limite_client":
                tag = "limite_client"
            elif c["heure_pcs_tbc"]:
                tag = "tbc"

            statut_label = {"normal": "", "lancement": "Lancement",
                             "limite_client": "Limite client"}.get(statut, "")

            self.tree.insert("", "end", iid=f"{c['id']}", values=(
                c["client"], c["modele"],
                "TBC" if c["heure_pcs_tbc"] else fmt(c["heure_pcs"]),
                fmt(pieces) if pieces else "",
                fmt(heures) if heures else "",
                fmt(brodeuses) if brodeuses else "",
                statut_label,
            ), tags=(tag,))

        total_brodeuses = logic.nb_brodeuses(total_heures)
        self.lbl_totaux.config(
            text=f"TOTAUX {code} — Pièces : {fmt(total_pieces)}   |   "
                 f"Heures : {fmt(round(total_heures, 2))}   |   "
                 f"Brodeuses nécessaires : {fmt(total_brodeuses)}"
        )

        niveau = logic.niveau_charge(total_brodeuses, sem["capacite_brodeuses"])
        niveau_txt = {
            "ok": ("🟩 Charge normale", "#2E7D32"),
            "tendu": ("🟧 Tendu", "#B26A00"),
            "surcharge": ("🟥 Dépassement de capacité", "#C62828"),
            "inconnu": ("Capacité non définie pour cette semaine", "#888888"),
        }[niveau]
        self.lbl_charge.config(text=niveau_txt[0], foreground=niveau_txt[1])

    def save_capacite(self):
        code = self.semaine_var.get()
        if not code:
            return
        sem = db.get_semaine_by_code(code)
        val = self.capacite_var.get().strip()
        if not val:
            db.set_capacite_semaine(sem["id"], None)
        else:
            try:
                nb = float(val.replace(",", "."))
            except ValueError:
                messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
                return
            db.set_capacite_semaine(sem["id"], nb)
        self.load_semaine()
        self.app.refresh_all(skip=self)

    def on_bulk_capacite(self):
        val = simpledialog.askstring(
            "Capacité pour plusieurs semaines",
            "Nombre de brodeuses disponibles à appliquer :",
            parent=self)
        if val is None:
            return
        try:
            nb = float(val.replace(",", "."))
        except ValueError:
            messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
            return
        only_unset = messagebox.askyesno(
            "Portée",
            "Appliquer UNIQUEMENT aux semaines qui n'ont pas encore de "
            "capacité définie ?\n\n"
            "Oui = ne remplit que les semaines vides (recommandé).\n"
            "Non = écrase aussi les valeurs déjà définies sur TOUTES les semaines.",
            parent=self)
        db.set_capacite_toutes_semaines(nb, only_if_unset=only_unset)
        self.load_semaine()
        self.app.refresh_all(skip=self)

    def on_double_click(self, event):
        item = self.tree.identify_row(event.y)
        col = self.tree.identify_column(event.x)
        if not item:
            return
        commande_id = int(item)
        sem = db.get_semaine_by_code(self.semaine_var.get())
        if not sem:
            return

        if col == "#4":  # Nb pièces
            self._edit_pieces(commande_id, sem["id"])
        elif col == "#7":  # Statut cellule
            self._edit_statut(commande_id, sem["id"])

    def _edit_pieces(self, commande_id, semaine_id):
        current = db.get_pieces(commande_id, semaine_id)
        val = simpledialog.askstring(
            "Nb pièces",
            "Nombre de pièces prévues cette semaine :",
            initialvalue=fmt(current["nb_pieces"]) if current else "0",
            parent=self,
        )
        if val is None:
            return
        try:
            nb = float(val.replace(",", "."))
        except ValueError:
            messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
            return
        db.set_pieces(commande_id, semaine_id, nb)
        self.load_semaine()
        self.app.refresh_all(skip=self)

    def _edit_statut(self, commande_id, semaine_id):
        win = tk.Toplevel(self)
        win.title("Statut de la cellule")
        win.resizable(False, False)
        ttk.Label(win, text="Choisir le statut :").pack(padx=15, pady=(15, 5))
        choix = tk.StringVar(value="normal")
        for val, label in [("normal", "Normal"), ("lancement", "Semaine de lancement"),
                            ("limite_client", "Limite livraison client")]:
            ttk.Radiobutton(win, text=label, variable=choix, value=val).pack(anchor="w", padx=25)

        def valider():
            db.set_statut(commande_id, semaine_id, choix.get())
            win.destroy()
            self.load_semaine()

        ttk.Button(win, text="Valider", command=valider).pack(pady=10)
        win.transient(self)
        win.grab_set()

    def set_as_current(self):
        code = self.semaine_var.get()
        if code:
            db.set_config("semaine_courante", code)
            self.app.refresh_all()


# =========================================================================
# Onglet : Vue Commande (planning détaillé multi-semaines pour 1 commande)
# =========================================================================
class OngletVueCommande(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.current_commande_id = None
        self._build()

    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="Commande :").pack(side="left")
        self.combo_var = tk.StringVar()
        self.combo = ttk.Combobox(top, textvariable=self.combo_var, state="readonly", width=60)
        self.combo.pack(side="left", padx=6)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.load_commande())

        self.info_lbl = ttk.Label(self, text="", font=("Calibri", 10, "bold"))
        self.info_lbl.pack(anchor="w", padx=8)

        cols = ("semaine", "date", "pieces", "heures", "brodeuses", "statut")
        headers = ["Semaine", "Date", "Nb pièces (éditable)", "Nb heures",
                   "Nb brodeuses", "Statut"]
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        for c, h in zip(cols, headers):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=130, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=8, pady=8)
        self.tree.bind("<Double-1>", self.on_double_click)

        self.tree.tag_configure("lancement", background=COLOR_LANCEMENT)
        self.tree.tag_configure("limite_client", background=COLOR_LIMITE)
        self.tree.tag_configure("courante", background=COLOR_COURANTE)

        help_lbl = ttk.Label(self, foreground="#666666",
                              text="Double-cliquez sur 'Nb pièces' pour éditer, "
                                   "ou sur 'Statut' pour marquer Lancement / Limite client.")
        help_lbl.pack(anchor="w", padx=8, pady=(0, 6))

    def refresh(self):
        commandes = db.list_commandes()
        self._map = {f'{c["client"]} — {c["modele"]} (#{c["id"]})': c["id"] for c in commandes}
        self.combo["values"] = list(self._map.keys())
        if self.current_commande_id:
            for label, cid in self._map.items():
                if cid == self.current_commande_id:
                    self.combo_var.set(label)
                    break
        elif not self.combo_var.get() and self._map:
            # rien de sélectionné pour l'instant -> afficher la 1ère commande par défaut
            first_label = next(iter(self._map))
            self.combo_var.set(first_label)
            self.current_commande_id = self._map[first_label]
        self.load_commande()

    def select_commande(self, commande_id):
        self.current_commande_id = commande_id
        self.refresh()

    def load_commande(self):
        label = self.combo_var.get()
        cid = self._map.get(label) if hasattr(self, "_map") else None
        if cid is None:
            self.tree.delete(*self.tree.get_children())
            self.info_lbl.config(text="")
            return
        self.current_commande_id = cid
        c = dict(db.get_commande(cid))
        reste = logic.qte_reste_a_faire(c["qte_commande"], c["qte_finie"])
        total_prog = db.total_pieces_commande(cid)
        statut = logic.statut_commande(c["qte_commande"], c["qte_finie"], total_prog)
        statut_txt = {"ok": "OK", "termine": "Terminé ✅",
                      "sous_planifie": "⚠ SOUS-PLANIFIÉ (planning insuffisant)"}[statut]
        heure_txt = "TBC (à confirmer)" if c["heure_pcs_tbc"] else f"{fmt(c['heure_pcs'])} h/pièce"

        self.info_lbl.config(
            text=f"Qté commande : {fmt(c['qte_commande'])} {c['unite']}   |   "
                 f"Qté finie : {fmt(c['qte_finie'])}   |   Reste à faire : {fmt(reste)}   |   "
                 f"{heure_txt}   |   Total programmé : {fmt(total_prog)}   |   Statut : {statut_txt}"
        )

        self.tree.delete(*self.tree.get_children())
        planning = db.planning_for_commande(cid)
        courante = db.get_config("semaine_courante")
        for s in db.list_semaines():
            p = planning.get(s["id"])
            pieces = p["nb_pieces"] if p else None
            statut_cell = p["statut"] if p else "normal"
            heures = logic.nb_heures(pieces or 0, c["heure_pcs"]) if not c["heure_pcs_tbc"] else None
            brodeuses = logic.nb_brodeuses(heures) if heures is not None else None

            tag = ""
            if statut_cell == "lancement":
                tag = "lancement"
            elif statut_cell == "limite_client":
                tag = "limite_client"
            elif s["code"] == courante:
                tag = "courante"

            statut_label = {"normal": "", "lancement": "Lancement",
                             "limite_client": "Limite client"}.get(statut_cell, "")

            self.tree.insert("", "end", iid=str(s["id"]), values=(
                s["code"], s["date_debut"], fmt(pieces) if pieces else "",
                fmt(heures) if heures else "", fmt(brodeuses) if brodeuses else "",
                statut_label,
            ), tags=(tag,))

    def on_double_click(self, event):
        item = self.tree.identify_row(event.y)
        col = self.tree.identify_column(event.x)
        if not item or self.current_commande_id is None:
            return
        semaine_id = int(item)
        if col == "#3":
            current = db.get_pieces(self.current_commande_id, semaine_id)
            val = simpledialog.askstring(
                "Nb pièces", "Nombre de pièces prévues :",
                initialvalue=fmt(current["nb_pieces"]) if current else "0", parent=self)
            if val is None:
                return
            try:
                nb = float(val.replace(",", "."))
            except ValueError:
                messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
                return
            db.set_pieces(self.current_commande_id, semaine_id, nb)
            self.load_commande()
            self.app.refresh_all(skip=self)
        elif col == "#6":
            win = tk.Toplevel(self)
            win.title("Statut")
            win.resizable(False, False)
            ttk.Label(win, text="Choisir le statut :").pack(padx=15, pady=(15, 5))
            choix = tk.StringVar(value="normal")
            for val, label in [("normal", "Normal"), ("lancement", "Semaine de lancement"),
                                ("limite_client", "Limite livraison client")]:
                ttk.Radiobutton(win, text=label, variable=choix, value=val).pack(anchor="w", padx=25)

            def valider():
                db.set_statut(self.current_commande_id, semaine_id, choix.get())
                win.destroy()
                self.load_commande()

            ttk.Button(win, text="Valider", command=valider).pack(pady=10)
            win.transient(self)
            win.grab_set()


# =========================================================================
# Fenêtre : Détail d'une semaine (double anneau client / commande)
# =========================================================================
class FenetreDetailSemaine(tk.Toplevel):
    """
    Fenêtre ouverte au clic sur une barre du graphique de charge.
    Affiche un double anneau (donut) :
      - anneau extérieur : répartition de la charge de la semaine par CLIENT
      - anneau intérieur : répartition par COMMANDE (imbriquée sous son client)
    Toutes les proportions sont exprimées en % du besoin total en brodeuses
    de la semaine.
    """
    def __init__(self, app, semaine_row):
        super().__init__(app)
        self.app = app
        self.semaine_id = semaine_row["id"]
        self.title(f"Détail de la charge — Semaine {semaine_row['code']}")
        self.geometry("1180x800")
        self.minsize(1050, 650)
        self.configure(bg=DASH_BG)

        self._build()
        self.refresh()

        self.transient(app)
        self.grab_set()

    def _build(self):
        header = tk.Frame(self, bg=DASH_BG)
        header.pack(fill="x", padx=18, pady=(16, 6))
        self.lbl_title = tk.Label(header, text="", bg=DASH_BG, font=("Calibri", 15, "bold"))
        self.lbl_title.pack(side="left")
        self.lbl_sub = tk.Label(header, text="", bg=DASH_BG, fg="#666666", font=("Calibri", 10))
        self.lbl_sub.pack(side="left", padx=14)
        ttk.Button(header, text="✏ Modifier la capacité",
                   command=self.on_edit_capacite).pack(side="right")

        body = tk.Frame(self, bg=DASH_BG)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        # -- colonne gauche : le double anneau --
        left = tk.Frame(body, bg=DASH_CARD_BG, highlightbackground="#DDDDDD",
                         highlightthickness=1)
        left.pack(side="left", fill="both", padx=(0, 8), pady=0)
        tk.Label(left, text="Répartition de la charge (% du besoin de la semaine)",
                 bg=DASH_CARD_BG, font=("Calibri", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 0))
        tk.Label(left, text="Anneau extérieur = par commande   |   Anneau intérieur = par client",
                 bg=DASH_CARD_BG, fg="#777777", font=("Calibri", 8, "italic")).pack(
            anchor="w", padx=12, pady=(0, 6))
        self.canvas = tk.Canvas(left, width=460, height=460, bg=DASH_CARD_BG, highlightthickness=0)
        self.canvas.pack(padx=12, pady=(0, 12))
        self.empty_lbl = tk.Label(left, text="Aucune pièce planifiée cette semaine.",
                                   bg=DASH_CARD_BG, fg="#888888", font=("Calibri", 10, "italic"))

        # -- colonne droite : détail chiffré (arborescence client -> commandes) --
        right = tk.Frame(body, bg=DASH_CARD_BG, highlightbackground="#DDDDDD",
                          highlightthickness=1)
        right.pack(side="left", fill="both", expand=True, pady=0)
        tk.Label(right, text="Détail chiffré (cliquez sur un client pour déplier)",
                 bg=DASH_CARD_BG, font=("Calibri", 10, "bold")).pack(anchor="w", padx=12, pady=(10, 6))

        cols = ("pct", "pieces", "heures", "brodeuses")
        headers = ["% semaine", "Pièces", "Heures", "Brodeuses"]
        self.tree = ttk.Treeview(right, columns=cols, show="tree headings")
        self.tree.heading("#0", text="Client / Commande")
        self.tree.column("#0", width=200)
        for c, h in zip(cols, headers):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=80, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        self.lbl_tbc_warning = tk.Label(right, text="", bg=DASH_CARD_BG, fg=DASH_ORANGE,
                                         font=("Calibri", 8, "italic"), wraplength=380, justify="left")
        self.lbl_tbc_warning.pack(anchor="w", padx=12, pady=(0, 12))

        footer = tk.Frame(self, bg=DASH_BG)
        footer.pack(fill="x", padx=18, pady=(0, 16))
        ttk.Button(footer, text="Fermer", command=self.destroy).pack(side="right")
        ttk.Button(footer, text="Ouvrir la Vue par semaine",
                   command=self.on_open_vue_semaine).pack(side="right", padx=8)

    # -- données --
    def _collect_data(self):
        """Retourne (clients_ordonnes, total_brodeuses, commandes_tbc_exclues)."""
        planning = db.planning_for_semaine(self.semaine_id)
        commandes = db.list_commandes()

        par_client = {}  # client -> {"total": float, "commandes": [(modele, pieces, heures, brodeuses)]}
        exclues_tbc = []
        for c in commandes:
            c = dict(c)
            p = planning.get(c["id"])
            if not p or not p["nb_pieces"]:
                continue
            if c["heure_pcs_tbc"] or not c["heure_pcs"]:
                exclues_tbc.append((c["client"], c["modele"], p["nb_pieces"]))
                continue
            heures = p["nb_pieces"] * c["heure_pcs"]
            brodeuses = logic.nb_brodeuses(heures) or 0
            entry = par_client.setdefault(c["client"], {"total": 0.0, "commandes": []})
            entry["total"] += brodeuses
            entry["commandes"].append((c["modele"], p["nb_pieces"], round(heures, 2), brodeuses))

        total = sum(e["total"] for e in par_client.values())
        clients_ordonnes = sorted(par_client.items(), key=lambda kv: -kv[1]["total"])
        return clients_ordonnes, total, exclues_tbc

    def _get_semaine(self):
        with db.get_conn() as conn:
            return conn.execute("SELECT * FROM semaines WHERE id=?", (self.semaine_id,)).fetchone()

    # -- rafraîchissement --
    def refresh(self):
        sem = self._get_semaine()

        self.lbl_title.config(text=f"Semaine {sem['code']}")
        cap = fmt(sem["capacite_brodeuses"]) if sem["capacite_brodeuses"] else "non définie"
        self.lbl_sub.config(text=f"Débute le {sem['date_debut']}   |   Capacité : {cap} brodeuse(s)")

        clients_ordonnes, total, exclues = self._collect_data()

        self.tree.delete(*self.tree.get_children())
        if total <= 0:
            self.canvas.pack_forget()
            self.empty_lbl.pack(padx=30, pady=60)
        else:
            self.empty_lbl.pack_forget()
            self.canvas.pack(padx=12, pady=(0, 12))
            self._draw_donut(clients_ordonnes, total)

        for i, (client, data) in enumerate(clients_ordonnes):
            pct_client = round(data["total"] / total * 100, 1) if total else 0
            client_item = self.tree.insert(
                "", "end", text=client, values=(f"{pct_client}%", "", "", fmt(round(data["total"], 2))),
                open=False, tags=("client",))
            for modele, pieces, heures, brodeuses in data["commandes"]:
                pct_cmd = round(brodeuses / total * 100, 1) if total else 0
                self.tree.insert(client_item, "end", text=modele,
                                  values=(f"{pct_cmd}%", fmt(pieces), fmt(heures), fmt(round(brodeuses, 2))))

        self.tree.tag_configure("client", font=("Calibri", 9, "bold"))

        if exclues:
            noms = ", ".join(f"{cl} — {mo}" for cl, mo, _ in exclues[:5])
            suffix = f" (+{len(exclues) - 5} autre(s))" if len(exclues) > 5 else ""
            self.lbl_tbc_warning.config(
                text=f"⚠ {len(exclues)} commande(s) avec des pièces prévues mais un temps de "
                     f"broderie non confirmé (TBC) ne sont pas incluses dans le graphique : "
                     f"{noms}{suffix}.")
        else:
            self.lbl_tbc_warning.config(text="")

    def _draw_donut(self, clients_ordonnes, total):
        self.canvas.delete("all")
        cx, cy = 230, 230
        r_outer, r_mid, r_inner = 200, 145, 90

        angle = 90.0
        client_angles = []  # (client, start, extent, color, data)
        for i, (client, data) in enumerate(clients_ordonnes):
            frac = data["total"] / total if total else 0
            extent = -360.0 * frac
            color = _client_color(i)
            client_angles.append((client, angle, extent, color, data))
            angle += extent

        # -- anneau EXTÉRIEUR : par commande (imbriquée dans l'angle de son client) --
        for client, start, extent, color, data in client_angles:
            sub_angle = start
            for j, (modele, pieces, heures, brodeuses) in enumerate(data["commandes"]):
                frac_cmd = (brodeuses / total) if total else 0
                sub_extent = -360.0 * frac_cmd
                shade = _shade_color(color, (-0.16 + 0.08 * (j % 3)))
                if frac_cmd > 0:
                    self.canvas.create_arc(cx - r_outer, cy - r_outer, cx + r_outer, cy + r_outer,
                                            start=sub_angle, extent=sub_extent, fill=shade,
                                            outline="white", width=1, style=tk.PIESLICE)
                sub_angle += sub_extent

        # trou central de l'anneau extérieur
        self.canvas.create_oval(cx - r_mid, cy - r_mid, cx + r_mid, cy + r_mid,
                                 fill=DASH_CARD_BG, outline="")

        # -- anneau INTÉRIEUR : par client --
        for client, start, extent, color, data in client_angles:
            if extent != 0:
                self.canvas.create_arc(cx - r_mid, cy - r_mid, cx + r_mid, cy + r_mid,
                                        start=start, extent=extent, fill=color, outline="white",
                                        width=1, style=tk.PIESLICE)

        self.canvas.create_oval(cx - r_inner, cy - r_inner, cx + r_inner, cy + r_inner,
                                 fill=DASH_CARD_BG, outline="")
        self.canvas.create_text(cx, cy - 10, text=fmt(round(total, 1)),
                                 font=("Calibri", 16, "bold"), fill="#333333")
        self.canvas.create_text(cx, cy + 12, text="brodeuses\nnécessaires", justify="center",
                                 font=("Calibri", 8), fill="#888888")

        import math
        for client, start, extent, color, data in client_angles:
            if abs(extent) < 14:
                continue
            mid_deg = start + extent / 2
            rad = math.radians(mid_deg)
            lx = cx + (r_outer + 16) * math.cos(rad)
            ly = cy - (r_outer + 16) * math.sin(rad)
            pct = round(data["total"] / total * 100, 0) if total else 0
            self.canvas.create_text(lx, ly, text=f"{client}\n{fmt(pct)}%",
                                     font=("Calibri", 7), fill="#444444", justify="center")

    # -- actions --
    def on_edit_capacite(self):
        sem = self._get_semaine()
        current = fmt(sem["capacite_brodeuses"]) if sem["capacite_brodeuses"] else ""
        val = simpledialog.askstring(
            f"Capacité — Semaine {sem['code']}",
            f"Nombre de brodeuses disponibles pour la semaine {sem['code']} :\n\n"
            f"Laissez vide pour effacer.",
            initialvalue=current, parent=self)
        if val is None:
            return
        val = val.strip()
        if not val:
            db.set_capacite_semaine(self.semaine_id, None)
        else:
            try:
                nb = float(val.replace(",", "."))
            except ValueError:
                messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
                return
            db.set_capacite_semaine(self.semaine_id, nb)
        self.refresh()
        self.app.refresh_all()

    def on_open_vue_semaine(self):
        sem = self._get_semaine()
        self.app.tab_semaine.semaine_var.set(sem["code"])
        self.app.tab_semaine.load_semaine()
        self.app.notebook.select(self.app.tab_semaine)
        self.destroy()


# =========================================================================
# Onglet : Tableau de bord (vue d'ensemble unique)
# =========================================================================
class KpiCard(tk.Frame):
    """Petite carte chiffrée colorée (indicateur clé)."""
    def __init__(self, parent, title, fg, bg):
        super().__init__(parent, bg=bg, highlightbackground="#DDDDDD",
                          highlightthickness=1, padx=14, pady=10)
        self.value_lbl = tk.Label(self, text="0", font=("Calibri", 24, "bold"), fg=fg, bg=bg)
        self.value_lbl.pack(anchor="w")
        tk.Label(self, text=title, font=("Calibri", 9), fg="#444444", bg=bg,
                 wraplength=150, justify="left").pack(anchor="w")

    def set_value(self, value):
        self.value_lbl.config(text=str(value))


class OngletTableauDeBord(ttk.Frame):
    """
    Vue d'ensemble unique : indicateurs clés, charge par semaine (graphique),
    et liste des points d'attention — pour repérer un problème en un coup d'œil.
    """
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.configure(style="Dash.TFrame")
        style = ttk.Style()
        style.configure("Dash.TFrame", background=DASH_BG)
        self._build()

    def _build(self):
        outer = tk.Frame(self, bg=DASH_BG)
        outer.pack(fill="both", expand=True)

        # --- bandeau titre + réglages ---
        header = tk.Frame(outer, bg=DASH_BG)
        header.pack(fill="x", padx=16, pady=(14, 6))
        tk.Label(header, text="Vue d'ensemble de la production", bg=DASH_BG,
                 font=("Calibri", 15, "bold")).pack(side="left")
        self.lbl_maj = tk.Label(header, text="", bg=DASH_BG, fg="#888888",
                                 font=("Calibri", 9))
        self.lbl_maj.pack(side="left", padx=12)
        ttk.Button(header, text="⚙ Capacité (plusieurs semaines)",
                   command=self.on_bulk_capacite).pack(side="right")

        # --- cartes indicateurs ---
        self.cards_frame = tk.Frame(outer, bg=DASH_BG)
        self.cards_frame.pack(fill="x", padx=16, pady=(4, 10))
        self.card_total = KpiCard(self.cards_frame, "Commandes actives", DASH_BLUE, DASH_BLUE_BG)
        self.card_retard = KpiCard(self.cards_frame, "Sous-planifiées\n(retard)", DASH_RED, DASH_RED_BG)
        self.card_tbc = KpiCard(self.cards_frame, "Heure/pcs\nà confirmer", DASH_ORANGE, DASH_ORANGE_BG)
        self.card_termine = KpiCard(self.cards_frame, "Terminées", DASH_GREEN, DASH_GREEN_BG)
        self.card_besoin = KpiCard(self.cards_frame, "Brodeuses nécessaires\ncette semaine", DASH_BLUE, DASH_BLUE_BG)
        self.card_capacite = KpiCard(self.cards_frame, "Capacité cette semaine\n(brodeuses dispo)", DASH_GREY, DASH_GREY_BG)
        for card in (self.card_total, self.card_retard, self.card_tbc,
                     self.card_termine, self.card_besoin, self.card_capacite):
            card.pack(side="left", padx=6, fill="y")

        # --- graphique de charge par semaine ---
        chart_box = tk.Frame(outer, bg=DASH_CARD_BG, highlightbackground="#DDDDDD",
                              highlightthickness=1)
        chart_box.pack(fill="x", padx=16, pady=(0, 10))
        tk.Label(chart_box, text="Charge en brodeuses par semaine (12 prochaines semaines)",
                 bg=DASH_CARD_BG, font=("Calibri", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 0))
        legend = tk.Frame(chart_box, bg=DASH_CARD_BG)
        legend.pack(anchor="w", padx=12, pady=(2, 6))
        for label, color in [("Charge normale (< 80% capacité)", DASH_GREEN),
                              ("Tendu (80-100%)", DASH_ORANGE),
                              ("Dépassement de capacité", DASH_RED)]:
            sq = tk.Frame(legend, bg=color, width=12, height=12)
            sq.pack(side="left", padx=(0, 4), pady=2)
            tk.Label(legend, text=label, bg=DASH_CARD_BG, font=("Calibri", 8),
                     fg="#555555").pack(side="left", padx=(0, 14))
        self.canvas = tk.Canvas(chart_box, height=220, bg=DASH_CARD_BG, highlightthickness=0,
                                 cursor="hand2")
        self.canvas.pack(fill="x", padx=12, pady=(0, 4))
        self.canvas.bind("<Button-1>", self._on_chart_click)
        self.canvas.bind("<Motion>", self._on_chart_hover)
        tk.Label(chart_box, text="💡 Cliquez sur une semaine du graphique pour voir le détail "
                                  "de la charge (par client / par commande) et ajuster sa capacité.",
                 bg=DASH_CARD_BG, fg="#888888", font=("Calibri", 8, "italic")).pack(
            anchor="w", padx=12, pady=(0, 10))
        self._chart_cols = []  # [(x0, x1, semaine_row), ...] rempli à chaque dessin
        self.hover_lbl = tk.Label(chart_box, text=" ", bg=DASH_CARD_BG, fg="#444444",
                                   font=("Calibri", 9, "bold"), anchor="w")
        self.hover_lbl.pack(fill="x", padx=12, pady=(2, 0))

        # --- points d'attention ---
        alert_box = tk.Frame(outer, bg=DASH_CARD_BG, highlightbackground="#DDDDDD",
                              highlightthickness=1)
        alert_box.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        tk.Label(alert_box, text="Points d'attention (triés par urgence)",
                 bg=DASH_CARD_BG, font=("Calibri", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 6))

        cols = ("gravite", "client", "modele", "probleme", "detail")
        headers = ["", "Client", "Modèle", "Problème", "Détail"]
        self.tree_alertes = ttk.Treeview(alert_box, columns=cols, show="headings", height=10)
        widths = {"gravite": 30, "client": 160, "modele": 220, "probleme": 170, "detail": 260}
        anchors = {"gravite": "center", "client": "w", "modele": "w",
                   "probleme": "w", "detail": "w"}
        for c, h in zip(cols, headers):
            self.tree_alertes.heading(c, text=h)
            self.tree_alertes.column(c, width=widths[c], anchor=anchors[c])
        self.tree_alertes.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.tree_alertes.tag_configure("retard", background=DASH_RED_BG)
        self.tree_alertes.tag_configure("tbc", background=DASH_ORANGE_BG)
        self.tree_alertes.bind("<Double-1>", self._on_double_click_alerte)
        self._alerte_commande_id = {}

        self.no_alert_lbl = tk.Label(alert_box, text="✅ Aucun point d'attention — tout est sous contrôle.",
                                      bg=DASH_CARD_BG, fg=DASH_GREEN, font=("Calibri", 10, "bold"))

    # -- réglages --
    def on_bulk_capacite(self):
        val = simpledialog.askstring(
            "Capacité pour plusieurs semaines",
            "Nombre de brodeuses disponibles à appliquer :\n"
            "(vous pouvez aussi régler une semaine précise dans l'onglet "
            "'Vue par semaine')",
            parent=self)
        if val is None:
            return
        try:
            nb = float(val.replace(",", "."))
        except ValueError:
            messagebox.showerror("Valeur invalide", "Entrez un nombre.", parent=self)
            return
        only_unset = messagebox.askyesno(
            "Portée",
            "Appliquer UNIQUEMENT aux semaines qui n'ont pas encore de "
            "capacité définie ?\n\n"
            "Oui = ne remplit que les semaines vides (recommandé).\n"
            "Non = écrase aussi les valeurs déjà définies sur TOUTES les semaines.",
            parent=self)
        db.set_capacite_toutes_semaines(nb, only_if_unset=only_unset)
        self.app.refresh_all()

    def _on_double_click_alerte(self, event):
        item = self.tree_alertes.identify_row(event.y)
        if not item:
            return
        cid = self._alerte_commande_id.get(item)
        if cid:
            self.app.open_plan_for_commande(cid)

    # -- rafraîchissement --
    def refresh(self):
        self.lbl_maj.config(
            text=f"(mis à jour maintenant — semaine en cours : "
                 f"{db.get_config('semaine_courante') or 'non définie'})")

        commandes = [dict(c) for c in db.list_commandes()]

        n_total = n_retard = n_tbc = n_termine = 0
        alertes = []  # (gravite_int, client, modele, probleme, detail, tag, commande_id)

        for c in commandes:
            reste = logic.qte_reste_a_faire(c["qte_commande"], c["qte_finie"])
            total_prog = db.total_pieces_commande(c["id"])
            statut = logic.statut_commande(c["qte_commande"], c["qte_finie"], total_prog)

            if statut == "termine":
                n_termine += 1
                continue  # une commande terminée n'est jamais un point d'attention

            n_total += 1
            manquant = round((reste or 0) - (total_prog or 0), 2)

            if statut == "sous_planifie":
                n_retard += 1
                deadline_txt = f" — livraison client : {c['date_limite_client']}" if c["date_limite_client"] else ""
                alertes.append((
                    0 if c["date_limite_client"] else 1,  # celles avec échéance en premier
                    c["client"], c["modele"], "Sous-planifiée",
                    f"{fmt(manquant)} pièces non affectées à une semaine{deadline_txt}",
                    "retard", c["id"],
                ))

            if c["heure_pcs_tbc"]:
                n_tbc += 1
                alertes.append((
                    2, c["client"], c["modele"], "Heure/pcs à confirmer",
                    "Impossible de calculer les heures/brodeuses tant que ce temps n'est pas connu",
                    "tbc", c["id"],
                ))

        # charge de la semaine en cours
        courante = db.get_config("semaine_courante")
        besoin_courante = None
        capacite_courante = None
        if courante:
            sem = db.get_semaine_by_code(courante)
            if sem:
                besoin_courante = self._besoin_semaine(sem["id"], commandes)
                capacite_courante = sem["capacite_brodeuses"]

        self.card_total.set_value(n_total)
        self.card_retard.set_value(n_retard)
        self.card_tbc.set_value(n_tbc)
        self.card_termine.set_value(n_termine)
        self.card_besoin.set_value(fmt(besoin_courante) if besoin_courante is not None else "—")
        self.card_capacite.set_value(fmt(capacite_courante) if capacite_courante else "non définie")

        # surcharge de capacité -> alertes prioritaires en haut
        semaines = db.list_semaines()
        for s in semaines:
            besoin = self._besoin_semaine(s["id"], commandes)
            niveau = logic.niveau_charge(besoin, s["capacite_brodeuses"])
            if niveau == "surcharge":
                alertes.insert(0, (
                    -1, "— Atelier —", f"Semaine {s['code']}", "Dépassement de capacité",
                    f"Besoin : {fmt(besoin)} brodeuses pour {fmt(s['capacite_brodeuses'])} disponibles",
                    "retard", None,
                ))

        alertes.sort(key=lambda a: a[0])

        self.tree_alertes.delete(*self.tree_alertes.get_children())
        self._alerte_commande_id = {}
        for gravite, client, modele, probleme, detail, tag, cid in alertes:
            icon = "🔴" if tag == "retard" else "🟠"
            item = self.tree_alertes.insert("", "end", values=(icon, client, modele, probleme, detail),
                                             tags=(tag,))
            if cid:
                self._alerte_commande_id[item] = cid

        if alertes:
            self.no_alert_lbl.pack_forget()
        else:
            self.no_alert_lbl.pack(anchor="w", padx=12, pady=(0, 12))

        self._draw_chart(semaines, commandes, courante)

    def _besoin_semaine(self, semaine_id, commandes):
        planning = db.planning_for_semaine(semaine_id)
        total_heures = 0
        for c in commandes:
            p = planning.get(c["id"])
            if not p or not p["nb_pieces"] or c["heure_pcs_tbc"] or not c["heure_pcs"]:
                continue
            total_heures += p["nb_pieces"] * c["heure_pcs"]
        return logic.nb_brodeuses(total_heures) or 0

    def _draw_chart(self, semaines, commandes, courante):
        self.canvas.delete("all")
        self.canvas.update_idletasks()
        width = max(self.canvas.winfo_width(), 800)
        height = 220
        self.canvas.config(scrollregion=(0, 0, width, height))

        codes = [s["code"] for s in semaines]
        start_idx = codes.index(courante) if courante in codes else 0
        semaines_visibles = semaines[start_idx:start_idx + 12] or semaines[:12]
        if not semaines_visibles:
            return

        besoins = [self._besoin_semaine(s["id"], commandes) for s in semaines_visibles]
        capacites = [s["capacite_brodeuses"] for s in semaines_visibles]
        capacites_connues = [c for c in capacites if c]

        # Échelle : on ignore le ou les pics extrêmes pour garder le graphique
        # lisible (sinon une seule semaine anormale écrase toutes les autres).
        sorted_besoins = sorted([b for b in besoins if b], reverse=True)
        if len(sorted_besoins) >= 2 and sorted_besoins[0] > sorted_besoins[1] * 2:
            max_plot = sorted_besoins[1] * 1.3
        elif sorted_besoins:
            max_plot = sorted_besoins[0] * 1.15
        else:
            max_plot = 1
        max_plot = max(max_plot, max(capacites_connues, default=0) * 1.3, 1)

        margin_left, margin_bottom, margin_top = 15, 32, 26
        plot_h = height - margin_bottom - margin_top
        n = len(semaines_visibles)
        bar_area_w = (width - margin_left - 10) / n

        self._chart_cols = []

        for i, (s, besoin, capacite) in enumerate(zip(semaines_visibles, besoins, capacites)):
            niveau = logic.niveau_charge(besoin, capacite)
            color = {"ok": DASH_GREEN, "tendu": DASH_ORANGE,
                     "surcharge": DASH_RED, "inconnu": DASH_BLUE}[niveau]
            capped = besoin > max_plot
            effective = min(besoin, max_plot) if besoin else 0
            bar_h = (effective / max_plot) * plot_h if max_plot else 0
            x0 = margin_left + i * bar_area_w + bar_area_w * 0.22
            x1 = margin_left + i * bar_area_w + bar_area_w * 0.78
            y1 = margin_top + plot_h
            y0 = y1 - bar_h

            # zone cliquable = toute la colonne (même au-dessus d'une petite barre)
            col_x0 = margin_left + i * bar_area_w
            col_x1 = margin_left + (i + 1) * bar_area_w
            self.canvas.create_rectangle(col_x0, margin_top - 14, col_x1, height,
                                          fill=DASH_CARD_BG, outline="", tags=("col",))
            self._chart_cols.append((col_x0, col_x1, s))

            self.canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="")

            if capped:
                # semaine hors-échelle : marqueur en dents de scie + valeur réelle en gras au-dessus du graphique
                for zz in range(int(x0), int(x1), 6):
                    self.canvas.create_line(zz, y0, zz + 3, y0 - 4, fill="white", width=1)
                self.canvas.create_text((x0 + x1) / 2, margin_top - 12,
                                         text=f"⚠ {fmt(besoin)}", font=("Calibri", 8, "bold"),
                                         fill=DASH_RED)
            elif besoin:
                self.canvas.create_text((x0 + x1) / 2, y0 - 9, text=fmt(besoin),
                                         font=("Calibri", 8), fill="#333333")

            # repère de capacité pour cette semaine (trait pointillé)
            if capacite:
                y_cap = y1 - min(capacite / max_plot, 1.0) * plot_h
                self.canvas.create_line(x0 - 2, y_cap, x1 + 2, y_cap,
                                         fill="#444444", dash=(3, 2), width=1.5)

            week_font = ("Calibri", 8, "bold") if s["code"] == courante else ("Calibri", 8)
            self.canvas.create_text((x0 + x1) / 2, y1 + 14, text=s["code"], font=week_font)

        # légende des repères pointillés (capacité)
        self.canvas.create_line(width - 150, height - 8, width - 130, height - 8,
                                 fill="#444444", dash=(3, 2), width=1.5)
        self.canvas.create_text(width - 124, height - 8, text="capacité de la semaine",
                                 anchor="w", font=("Calibri", 7), fill="#666666")

    def _semaine_at_x(self, x):
        for x0, x1, s in self._chart_cols:
            if x0 <= x <= x1:
                return s
        return None

    def _on_chart_hover(self, event):
        s = self._semaine_at_x(event.x)
        if s:
            cap = fmt(s["capacite_brodeuses"]) if s["capacite_brodeuses"] else "non définie"
            self.hover_lbl.config(text=f"Semaine {s['code']} ({s['date_debut']}) — "
                                        f"capacité : {cap} brodeuse(s)  —  cliquez pour modifier")
        else:
            self.hover_lbl.config(text=" ")

    def _on_chart_click(self, event):
        s = self._semaine_at_x(event.x)
        if not s:
            return
        FenetreDetailSemaine(self.app, s)


# =========================================================================
# Application principale
# =========================================================================
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1250x700")

        db.init_db()

        self._build_menu()

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        self.tab_dashboard = OngletTableauDeBord(self.notebook, self)
        self.tab_commandes = OngletCommandes(self.notebook, self)
        self.tab_semaine = OngletVueSemaine(self.notebook, self)
        self.tab_commande_detail = OngletVueCommande(self.notebook, self)

        self.notebook.add(self.tab_dashboard, text="  📊 Tableau de bord  ")
        self.notebook.add(self.tab_commandes, text="  Commandes  ")
        self.notebook.add(self.tab_semaine, text="  Vue par semaine  ")
        self.notebook.add(self.tab_commande_detail, text="  Vue par commande  ")

        self.notebook.bind("<<NotebookTabChanged>>", lambda e: self.refresh_all())

        self.tab_dashboard.refresh()
        self.tab_commande_detail.refresh()

    def _build_menu(self):
        menubar = tk.Menu(self)

        m_fichier = tk.Menu(menubar, tearoff=0)
        m_fichier.add_command(label="Importer un fichier Excel existant…",
                               command=self.on_import_excel)
        m_fichier.add_command(label="Exporter le planning en Excel…",
                               command=self.on_export_excel)
        m_fichier.add_separator()
        m_fichier.add_command(label="Quitter", command=self.destroy)
        menubar.add_cascade(label="Fichier", menu=m_fichier)

        m_semaines = tk.Menu(menubar, tearoff=0)
        m_semaines.add_command(label="Ajouter une semaine…", command=self.on_add_semaine)
        menubar.add_cascade(label="Semaines", menu=m_semaines)

        m_aide = tk.Menu(menubar, tearoff=0)
        m_aide.add_command(label="À propos", command=self.on_about)
        menubar.add_cascade(label="Aide", menu=m_aide)

        self.config(menu=menubar)

    def refresh_all(self, skip=None):
        if skip is not self.tab_dashboard:
            self.tab_dashboard.refresh()
        if skip is not self.tab_commandes:
            self.tab_commandes.refresh()
        if skip is not self.tab_semaine:
            self.tab_semaine.refresh()
        if skip is not self.tab_commande_detail:
            self.tab_commande_detail.refresh()

    def open_plan_for_commande(self, commande_id):
        self.tab_commande_detail.select_commande(commande_id)
        self.notebook.select(self.tab_commande_detail)

    def on_import_excel(self):
        path = filedialog.askopenfilename(
            title="Choisir le fichier Excel à importer",
            filetypes=[("Fichiers Excel", "*.xlsx")])
        if not path:
            return
        if not messagebox.askyesno(
                "Confirmer l'import",
                "L'import va AJOUTER les commandes et semaines du fichier choisi "
                "à la base actuelle (les commandes existantes ne sont pas supprimées).\n\n"
                "Continuer ?"):
            return
        try:
            resume = excel_import.import_xlsx(path)
        except Exception as e:
            messagebox.showerror("Erreur d'import", str(e))
            return
        messagebox.showinfo(
            "Import terminé",
            f"{resume['commandes_importees']} commande(s) et "
            f"{resume['semaines_importees']} semaine(s) importées "
            f"({resume['lignes_planning_importees']} lignes de planning).")
        self.refresh_all()

    def on_export_excel(self):
        code_courante = db.get_config("semaine_courante")
        path = filedialog.asksaveasfilename(
            title="Enregistrer le planning au format Excel",
            defaultextension=".xlsx",
            initialfile=f"MACRO-PLANNING_BROD_TRADI_{code_courante or ''}.xlsx",
            filetypes=[("Fichiers Excel", "*.xlsx")])
        if not path:
            return
        try:
            excel_export.export_xlsx(path, semaine_courante_code=code_courante)
        except Exception as e:
            messagebox.showerror("Erreur d'export", str(e))
            return
        messagebox.showinfo("Export terminé", f"Fichier enregistré :\n{path}")

    def on_add_semaine(self):
        code = simpledialog.askstring("Nouvelle semaine", "Code semaine (ex: S52) :", parent=self)
        if not code:
            return
        date_str = simpledialog.askstring(
            "Nouvelle semaine", "Date de début (lundi, AAAA-MM-JJ) :", parent=self)
        if not date_str:
            return
        try:
            datetime.datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Date invalide", "Format attendu : AAAA-MM-JJ")
            return
        db.add_semaine(code.strip(), date_str.strip())
        self.refresh_all()

    def on_about(self):
        messagebox.showinfo(
            "À propos",
            f"{APP_TITLE}\n\n"
            "Outil 100% hors-ligne de gestion du macro-planning de broderie.\n"
            "Toutes les données sont stockées localement (planning.db).\n\n"
            "Développé sur mesure à partir du fichier "
            "MACRO-PLANNING_BROD_TRADI.xlsx.")


def main():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
