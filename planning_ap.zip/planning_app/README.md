# Macro-Planning Broderie — Outil hors-ligne

Application de bureau (Python + interface graphique Tkinter) pour gérer le
macro-planning de production broderie, à partir du fichier
`MACRO-PLANNING_BROD_TRADI_S34.xlsx`.

**100 % hors-ligne** : aucune donnée n'est envoyée sur internet. Tout est
stocké localement dans un fichier `planning.db` (base SQLite) à côté du
programme.

---

## 1. Installation

Prérequis : **Python 3.9 ou supérieur** (Windows, Mac ou Linux).

1. Vérifiez que Python est installé :
   ```
   python --version
   ```
   (sous Mac/Linux, utilisez parfois `python3` à la place de `python`)

2. Installez la seule dépendance externe (`openpyxl`, pour lire/écrire les
   fichiers Excel) :
   ```
   pip install -r requirements.txt
   ```
   ou directement :
   ```
   pip install openpyxl
   ```

   > `tkinter` (l'interface graphique) est fourni avec Python sur
   > Windows/Mac. Sous Linux (Ubuntu/Debian), si l'application ne démarre
   > pas, installez-le avec : `sudo apt-get install python3-tk`

3. Le dossier contient déjà une base **`planning.db` pré-remplie** avec les
   données du fichier `MACRO-PLANNING_BROD_TRADI_S34.xlsx` que vous avez
   fourni (44 commandes, 23 semaines S29 à S51, semaine courante = S34).

## 2. Lancement

```
python main.py
```

Une fenêtre s'ouvre avec 4 onglets.

## 3. Les 4 onglets

### 📊 Tableau de bord (vue d'ensemble — à consulter en premier)
C'est l'écran d'accueil : il donne en un coup d'œil l'état de toute la
production, sans avoir à naviguer.
- **6 indicateurs chiffrés** en haut : nombre de commandes actives, nombre
  en retard (sous-planifiées), nombre avec une heure/pièce encore à
  confirmer (TBC), nombre terminées, brodeuses nécessaires cette semaine,
  et la capacité **de la semaine en cours** que vous avez renseignée.
- **Graphique de charge** : une barre par semaine (les 12 prochaines à
  partir de la semaine en cours), montrant le nombre de brodeuses
  nécessaires. **Cliquez sur une semaine** pour ouvrir une fenêtre de
  détail avec :
  - un **double anneau** (donut) : l'anneau extérieur répartit la charge
    de la semaine **par client** (en %), l'anneau intérieur la répartit
    **par commande**, imbriquée sous son client — pour voir en un coup
    d'œil qui pèse le plus dans la charge de cette semaine ;
  - un **tableau détaillé dépliable** (client → commandes) avec le %,
    les pièces, heures et brodeuses de chacun ;
  - un bouton pour **modifier la capacité** de cette semaine directement
    depuis cette fenêtre.
  Le survol (sans cliquer) d'une barre affiche un aperçu rapide de la
  capacité de la semaine juste sous le graphique.
  Couleur des barres, calculée par rapport à **la capacité propre à
  chaque semaine** (l'effectif de brodeuses disponibles peut varier d'une
  semaine à l'autre) :
  - 🟩 vert = charge normale (moins de 80 % de la capacité de cette semaine)
  - 🟧 orange = tendu (80-100 %)
  - 🟥 rouge = dépassement de la capacité de cette semaine
  - 🔵 bleu = capacité non renseignée pour cette semaine (pas de comparaison possible)
  Un trait pointillé sous chaque barre indique la capacité disponible
  cette semaine-là. Si une semaine a un besoin beaucoup plus élevé que les
  autres, sa barre est tronquée avec un motif en dents de scie et sa
  valeur réelle s'affiche en gras au-dessus (⚠), pour ne pas écraser la
  lisibilité des autres semaines.
- **Points d'attention** : la liste, triée par urgence, de tout ce qui
  mérite un regard — semaines en dépassement de capacité, commandes
  sous-planifiées (avec le nombre de pièces manquantes), heures/pièce à
  confirmer. Double-cliquez sur une ligne pour ouvrir directement le
  planning détaillé de la commande concernée.
- **⚙ Capacité (plusieurs semaines)** (bouton en haut à droite) : permet
  de renseigner rapidement une capacité pour plusieurs semaines d'un coup
  (par exemple au démarrage). Pour ajuster une semaine précise (effectif
  qui change), utilisez plutôt l'onglet **Vue par semaine** (voir
  ci-dessous) — c'est l'endroit prévu pour ça.

### 🟦 Commandes
Liste de toutes les commandes (client, modèle, quantités, heure/pièce...).
Un bandeau en haut rappelle la signification de chaque statut :
- **En cours — planifiée** (bleu) : ni en retard, ni terminée. Le planning
  actuel couvre suffisamment le reste à faire.
- **Sous-planifiée (retard)** (rouge) : le total prévu sur les semaines ne
  couvre pas le reste à faire — il manque des pièces non affectées à une
  semaine. C'est le signal d'alerte à traiter.
- **Terminée** (vert) : reste à faire ≤ 0.
- **Heure/pcs à confirmer** (orange) : le temps de broderie unitaire n'est
  pas encore connu (« TBC ») — impossible de calculer heures/brodeuses
  tant que cette valeur n'est pas renseignée.

Boutons :
- **+ Ajouter** : créer une nouvelle commande.
- **Modifier** : éditer les infos d'une commande sélectionnée.
- **Dupliquer** : copier une commande (pratique pour un nouveau coloris).
- **Supprimer** : retirer une commande et tout son planning.
- **Planifier ➜** (ou double-clic) : ouvre la vue détaillée
  semaine-par-semaine de cette commande.

### 🟩 Vue par semaine
Sélectionnez une semaine (ex. S34) dans le menu déroulant : vous voyez
toutes les commandes avec leur **nombre de pièces prévues cette semaine**
(double-cliquez pour éditer), le nombre d'heures et de brodeuses nécessaires
calculés automatiquement. Les totaux de la semaine s'affichent en bas.
- **Brodeuses disponibles cette semaine** : indiquez ici l'effectif réel
  pour CETTE semaine précise, puis **Enregistrer**. Un badge s'affiche
  aussitôt à côté (🟩 charge normale / 🟧 tendu / 🟥 dépassement de
  capacité) et le Tableau de bord se met à jour en conséquence. C'est
  l'endroit à utiliser chaque semaine pour refléter les variations
  d'effectif (embauches, absences, intérim...).
- **Appliquer à plusieurs semaines…** : pour initialiser rapidement la
  capacité de toutes les semaines encore vides avec une même valeur par
  défaut, sans écraser celles déjà renseignées individuellement.
- **Définir comme semaine en cours** : marque cette semaine comme la
  semaine active (surbrillance jaune, utilisée aussi à l'export Excel et
  comme point de départ du graphique du Tableau de bord).
- Double-cliquez sur **Statut cellule** pour marquer une case comme
  "Semaine de lancement" (orange) ou "Limite livraison client" (rouge),
  comme dans le fichier Excel d'origine.

### 🟨 Vue par commande
Sélectionnez une commande : vous voyez tout son planning sur les 23
semaines (ou plus), avec les mêmes possibilités d'édition et de statut.
Pratique pour étaler la production d'un modèle sur plusieurs semaines.

## 4. Calculs automatiques (identiques au fichier Excel d'origine)

- **Qté reste à faire** = Qté en commande − Qté finie
- **Nb heures (semaine)** = Nb pièces prévues × Heure/pièce
- **Nb brodeuses nécessaires** = Nb heures ÷ 40 (base 40h/semaine/brodeuse)
- **Total programmé** = somme des pièces prévues sur toutes les semaines
- Une commande est **sous-planifiée** si le total programmé est inférieur
  au reste à faire.
- **Niveau de charge d'une semaine** (Tableau de bord) = besoin en
  brodeuses ÷ capacité de l'atelier renseignée : < 80 % → normal,
  80-100 % → tendu, > 100 % → dépassement de capacité.

## 5. Import / Export Excel

Menu **Fichier** :
- **Importer un fichier Excel existant…** : relit un fichier au même
  format que `MACRO-PLANNING_BROD_TRADI_Sxx.xlsx` et **ajoute** ses
  commandes/semaines à la base actuelle (rien n'est écrasé).
- **Exporter le planning en Excel…** : régénère un fichier `.xlsx` avec
  la même mise en page que l'original (dates, semaines, couleurs légende)
  à partir des données actuelles de l'application — pratique pour
  partager un planning à jour par e-mail ou l'imprimer.

  > Note : contrairement au fichier Excel d'origine, l'export contient des
  > **valeurs déjà calculées** (pas de formules Excel), car tous les calculs
  > sont faits par l'application elle-même. Si vous modifiez une valeur dans
  > le fichier exporté, elle ne se recalculera pas automatiquement — modifiez
  > plutôt les données dans l'application, puis ré-exportez.

## 6. Ajouter une nouvelle semaine

Menu **Semaines ▸ Ajouter une semaine…**, indiquez le code (ex. `S52`) et
la date du lundi de cette semaine (format `AAAA-MM-JJ`).

## 7. Sauvegarde des données

Toutes vos modifications sont enregistrées **immédiatement et
automatiquement** dans `planning.db` (pas de bouton "Enregistrer" à
penser). Pour sauvegarder/archiver une version, il suffit de copier ce
fichier `planning.db` ailleurs. Pour repartir de zéro, supprimez-le : il
sera recréé vide au prochain lancement.

## 8. Structure des fichiers du projet

```
planning_app/
├── main.py            → lancer l'application (python main.py)
├── gui.py              → interface graphique (les 4 onglets)
├── db.py                → accès à la base de données locale (SQLite)
├── logic.py             → règles de calcul (heures, brodeuses, retards)
├── excel_import.py    → import d'un fichier Excel existant
├── excel_export.py    → génération d'un rapport Excel formaté
├── planning.db          → vos données (créé/rempli automatiquement)
├── requirements.txt   → dépendances (openpyxl)
└── README.md            → ce document
```

## 9. Questions fréquentes

**L'application ne démarre pas / erreur `tkinter`.**
Sous Linux : `sudo apt-get install python3-tk`. Sous Windows/Mac,
réinstallez Python depuis python.org en cochant l'option tcl/tk lors de
l'installation.

**Puis-je utiliser l'application sur plusieurs ordinateurs ?**
Oui, copiez tout le dossier `planning_app` (avec `planning.db`) sur une clé
USB ou un dossier partagé. Attention : si deux personnes modifient le même
`planning.db` en même temps depuis deux ordinateurs différents, la dernière
sauvegarde écrasera l'autre (pas de fusion automatique).

**Comment revenir au fichier Excel d'origine ?**
Le fichier `MACRO-PLANNING_BROD_TRADI_S34.xlsx` que vous avez fourni n'est
pas modifié par l'application. Vous pouvez toujours l'ouvrir normalement
dans Excel.
